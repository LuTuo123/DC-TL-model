%% Compute wi and plot the DC-JL model against experimental data
% This script:
% 1) Loads the experimental stress-strain data at N = 0
% 2) Computes the plastic-term area difference AP
% 3) Computes the softening-term area difference AS
% 4) Evaluates wi = AP / (AP + AS)
% 5) Uses the DC-JL model to compute the fitted deviatoric stress
% 6) Plots the experimental data and the model prediction

close all
clc

%% Step 1: Input experimental stress-strain data at N = 0
data = [...
0.000  0.00
0.005  133.18
0.010  224.54
0.015  259.93
0.020  275.03
0.025  273.19
0.030  269.60
0.035  267.25
0.040  264.75
0.045  262.35
0.050  260.15
0.055  258.18
0.060  256.41
0.065  254.83
0.070  253.42
0.075  252.16
0.080  251.02
0.085  250.00
0.090  249.07
0.095  248.23
0.100  247.46
0.105  246.76
0.110  246.11
0.115  245.52
0.120  244.97
0.125  244.46
0.130  243.99
0.135  243.55
0.140  243.14
0.145  242.76
0.150  242.40];

%% Step 2: Key model parameters
es  = 0.016;     % Yield strain
ef  = 0.020;     % Failure strain
E0  = 22475;     % Initial elastic modulus, kPa
TSS = 275.03;    % Peak strength, kPa

x = data(:,1);
y = data(:,2);

% Avoid numerical issues such as log(0) or 0^0
x(1) = max(x(1), eps);

a = 1 / E0;
b = 1 / TSS;

%% Step 3: Compute the plastic term
% Since wi = 0 in the plastic-term formulation, the weighting factor is omitted
p = max(1 - (x / es).^2, 0);
xPowP = x.^p;

Pl = xPowP ./ (a .* p + b .* xPowP);

% Duncan-Chang reference model
Duncan = x ./ (a + b .* x);


% Compute the area difference over the range x > ef
AP = curve_area(x, y, Pl, ef);
fprintf('AP = %.10f\n', AP);

%% Step 4: Compute the softening term
m = 1 / TSS - 2 / (E0 * ef);
l = 1 / (E0 * ef^2);

So = x ./ (a + m .* x + l .* x.^2);

% Analytical and numerical derivatives of the softening term
dSo_ana = (a - l .* x.^2) ./ (a + m .* x + l .* x.^2).^2; %

AS = curve_area(x, y, So, ef);
fprintf('AS = %.10f\n', AS);

%% Step 5: Compute wi
wi = AP / (AP + AS);
fprintf('wi = %.10f\n', wi);

%% Step 6: Compute the deviatoric stress using the DC-JL model
xFit = (0:0.005:0.30).';   % Column vector for plotting
[yFit, ~] = DCJL_model(xFit, E0, TSS, wi, es, ef);
yFit = yFit(:);

[yFit2, ~] = DCJL_model(x, E0, TSS, wi, es, ef);
%% Step 7: Validation
[R2, RMSE, MAPE]=R2_MAPE(y,yFit2)

%% Step 8: Plot experimental data and model prediction
fig = figure('Color', 'w');
ax = axes(fig);
hold(ax, 'on');
% Define a simple color palette
dataColor = [0.00 0.30 0.30];
fitColor  = [0.85 0.33 0.10];

% Plot experimental data
s = scatter(ax, x, y, 42, ...
    'o', ...
    'filled', ...
    'DisplayName', 'Experimental data');
s.MarkerFaceColor = dataColor;
s.MarkerEdgeColor = 'w';
s.LineWidth = 0.8;
s.MarkerFaceAlpha = 0.90;
s.MarkerEdgeAlpha = 0.90;

% Plot DC-JL model
plot(ax, xFit, yFit, '--', ...
    'Color', fitColor, ...
    'LineWidth', 2.2, ...
    'DisplayName', 'DC-JL model');

% Label the axes and title
xlabel(ax, 'Strain', 'FontSize', 12, 'FontWeight', 'bold');
ylabel(ax, 'Deviatoric stress (kPa)', 'FontSize', 12, 'FontWeight', 'bold');
title(ax, 'Experimental Data and DC-JL Model', ...
    'FontSize', 13, 'FontWeight', 'bold');

% Improve axis appearance
ax.FontSize = 11;
ax.LineWidth = 1.0;
ax.Box = 'off';
ax.TickDir = 'out';
ax.XGrid = 'on';
ax.YGrid = 'on';
ax.GridAlpha = 0.15;
ax.MinorGridAlpha = 0.08;

% Set axis limits
xlim(ax, [0 0.30]);
ylim(ax, [0 max([y; yFit]) * 1.08]);

% Create legend without border
lgd = legend(ax, 'Location', 'northeast');
lgd.Box = 'off';
lgd.FontSize = 11;

% Set figure size for export
set(fig, 'Position', [100 100 760 460]);

%% Step 8: Save wi to a MAT-file
save('mydata.mat', 'wi');

%% Local functions
function A = curve_area(x, y1, y2, xMin)
%CURVE_AREA Compute the absolute area difference between two curves.
%   A = CURVE_AREA(x, y1, y2, xMin) computes the area of the absolute
%   difference |y1 - y2| over the interval where x > xMin.

idx = x > xMin;
xf = x(idx);
df = abs(y1(idx) - y2(idx));

if numel(xf) < 2
    error('Not enough data points for integration.');
end

A = simpson_or_trapz(xf, df);

end

function A = simpson_or_trapz(x, y)
%SIMPSON_OR_TRAPZ Integrate y with respect to x.
%   A = SIMPSON_OR_TRAPZ(x, y) uses Simpson''s rule when:
%   - x is uniformly spaced
%   - the number of points is odd
%   Otherwise, it falls back to trapz.

n = numel(x);
dx = diff(x);

% Check whether x is approximately uniformly spaced
isUniform = all(abs(dx - dx(1)) <= 100 * eps(max(abs(x)) + 1));

if isUniform && mod(n, 2) == 1
    h = dx(1);
    A = h / 3 * ( ...
        y(1) + y(end) + ...
        4 * sum(y(2:2:end-1)) + ...
        2 * sum(y(3:2:end-2)) );
else
    A = trapz(x, y);
end

end